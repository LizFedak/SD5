package dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.transaction.annotation.Transactional;

import entities.Employee;

@Transactional
public class CompanyDBJPADAO implements CompanyDBDAO {
	@PersistenceContext
	private EntityManager em;

	@Override
	public Employee getEmployee(int id) {
		Employee emp = em.find(Employee.class, id);
		em.detach(emp);
		return emp;
	}
	@Override
	public void updateEmployee(int id, Employee emp) {
		Employee managedEmp = em.find(Employee.class, id);
		managedEmp.setFirstName(emp.getFirstName());
		managedEmp.setLastName(emp.getLastName());
	}
}
