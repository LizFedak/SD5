package dao;

import entities.Employee;

public interface CompanyDBDAO {
	public Employee getEmployee(int id);
	public void updateEmployee(int id, Employee emp);
}
