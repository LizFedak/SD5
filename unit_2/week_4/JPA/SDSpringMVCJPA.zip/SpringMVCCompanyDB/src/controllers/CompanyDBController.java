package controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import dao.CompanyDBDAO;
import entities.Employee;

@Controller
public class CompanyDBController {
	@Autowired
	private CompanyDBDAO companyDAO;
	
	@RequestMapping(path="GetEmployee.do", method=RequestMethod.GET)
	public ModelAndView getEmployee() {
		return new ModelAndView("getEmployee.jsp");
	}

	@RequestMapping(path="GetEmployee.do", method=RequestMethod.POST)
	public ModelAndView getEmployee(int id) {
		Employee emp = companyDAO.getEmployee(id);
		return new ModelAndView("employee.jsp", "emp", emp);
	}
	
	@RequestMapping(path="EditEmployee.do", method=RequestMethod.GET)
	public ModelAndView editEmployee(int id) {
		Employee emp = companyDAO.getEmployee(id);
		return new ModelAndView("editEmployee.jsp", "emp", emp);

	}
	
	@RequestMapping(path="EditEmployee.do", method=RequestMethod.POST)
	public ModelAndView editEmployee(int id, Employee emp) {
		companyDAO.updateEmployee(id, emp);
		return new ModelAndView("employee.jsp", "emp", companyDAO.getEmployee(id));
	}
}
