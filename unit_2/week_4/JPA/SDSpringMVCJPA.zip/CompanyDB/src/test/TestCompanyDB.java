package test;



import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import entities.Department;
import entities.Employee;
import entities.Gender;
import entities.Job;
import entities.Location;
import entities.Project;
import entities.State;

public class TestCompanyDB {
	private EntityManagerFactory emf;
	private EntityManager em;

	@Before
	public void setUp() throws Exception {
		emf = Persistence.createEntityManagerFactory("CompanyDB");
		em = emf.createEntityManager();
	}
	
	@Test
	public void testManyToMany() {
		Employee emp = em.find(Employee.class, 1002);
		assertEquals(1, emp.getProjects().size());
		assertEquals("Oscillation Overthruster", emp.getProjects().get(0).getName());
		
		Project proj = em.find(Project.class, 1);
		assertEquals(28, proj.getEmployees().size());
	}

	@Test
	public void testJob() {
		Job j = em.find(Job.class, 1);
		assertEquals(1, j.getId());
		assertEquals("President", j.getName());
		assertEquals(80000, j.getMinimumSalary());
		assertEquals(100000, j.getMaximumSalary());
		assertEquals(1, j.getEmployees().size());
	}
	@Test
	public void testLocation() {
		Location loc = em.find(Location.class, 1);
		assertEquals(1, loc.getId());
		assertEquals(new Integer(6300), loc.getSquareFootage());
		assertEquals("Atlanta", loc.getAddress().getCity());
		assertEquals(State.GA, loc.getAddress().getState());
		
		assertEquals(2, loc.getDepartments().size());
	}
	
	@Test
	public void testDepartment() {
		Department dept = em.find(Department.class, 1);
		assertEquals(1, dept.getId());
		assertEquals("Research", dept.getName());
		assertEquals("Grover's Mill", dept.getLocation().getAddress().getCity());
		assertEquals(35, dept.getEmployees().size());
		
		assertEquals(1062, dept.getManager().getId());
	}
	
	@Test
	public void testEmployee() {
		Employee emp = em.find(Employee.class, 1001);
		
		assertNull(emp.getDepartmentManaged());
		
		assertEquals(1001, emp.getId());
		assertEquals("Patrick", emp.getFirstName());
		assertEquals("", emp.getMiddleName());
		assertEquals("Acosta", emp.getLastName());
		assertEquals(new Integer(61000), emp.getSalary());
		assertNull(emp.getCommissionPct());
		assertEquals("1986-08-13", emp.getHireDate().toString());
		assertEquals(Gender.M, emp.getGender());
		assertEquals("Atlanta", emp.getAddress().getCity());
		assertEquals(State.GA, emp.getAddress().getState());

		assertEquals("Manager", emp.getJob().getName());
		assertEquals("Operations", emp.getDepartment().getName());
	}
	

	@After
	public void tearDown() throws Exception {
		em.close();
		emf.close();
	}

}
