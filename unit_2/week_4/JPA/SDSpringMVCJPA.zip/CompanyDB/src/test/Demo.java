package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entities.Job;

public class Demo {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("CompanyDB");
		EntityManager em = emf.createEntityManager();
		
		Job job = em.find(Job.class, 1);
		System.out.println(job.getName());

		em.close();
		emf.close();
	}
}
