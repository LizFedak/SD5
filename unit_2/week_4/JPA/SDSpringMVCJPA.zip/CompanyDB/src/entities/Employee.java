package entities;

import java.util.Date;
import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "EMPLOYEES")
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@ManyToMany
	@JoinTable(name="Assignments",
	  joinColumns = @JoinColumn(name="employee_id"),
	  inverseJoinColumns= @JoinColumn(name="project_id"))
	private List<Project> projects;
	
	@OneToMany(mappedBy="employee")
	private List<Assignment> assignments;
	
	@ManyToOne
	@JoinColumn(name="department_id")
	private Department department;

	@OneToOne(mappedBy="manager")
	private Department departmentManaged;
	
	private String firstName;
	private String middleName;
	private String lastName;
	@Enumerated(EnumType.STRING)
	private Gender gender;
	private Integer salary;
	@Column(name="commission_pct")
	private Integer commissionPct;
	@Temporal(TemporalType.DATE)
	private Date hireDate;
	
	@Embedded
	@AttributeOverride(name="streetAddress",
	    column = @Column(name="address"))
	private Address address;
	
	@ManyToOne
	@JoinColumn(name="job_id")
	private Job job;
	

	
	public Employee() {

	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public Integer getCommissionPct() {
		return commissionPct;
	}

	public void setCommissionPct(Integer commissionPct) {
		this.commissionPct = commissionPct;
	}

	public Date getHireDate() {
		return hireDate;
	}

	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Job getJob() {
		return job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", department=" + department.getName() + ", firstName=" + firstName + ", middleName="
				+ middleName + ", lastName=" + lastName + ", gender=" + gender + ", salary=" + salary
				+ ", commissionPct=" + commissionPct + ", hireDate=" + hireDate + ", address=" + address + ", job="
				+ job + "]";
	}

	public Department getDepartmentManaged() {
		return departmentManaged;
	}

	public void setDepartmentManaged(Department departmentManaged) {
		this.departmentManaged = departmentManaged;
	}

	public List<Project> getProjects() {
		return projects;
	}

	public void setProjects(List<Project> projects) {
		this.projects = projects;
	}

	public List<Assignment> getAssignments() {
		return assignments;
	}

	public void setAssignments(List<Assignment> assignments) {
		this.assignments = assignments;
	}

}
