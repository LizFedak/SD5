package entities;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;

@Entity
@Table(name = "DEPARTMENTS")
public class Department {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String name;
	@ManyToOne
	@JoinColumn(name="location_id")
	private Location location;
	
	@OneToOne
	@JoinColumn(name="manager_id")
	private Employee manager;
	
	@OneToMany(mappedBy="department")
	@OrderBy("salary DESC")
	private List<Employee> employees;

	
	public Department() {
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	@Override
	public String toString() {
		return "Department [id=" + id + ", name=" + name + ", location=" + location + ", employees=" + employees + "]";
	}

	public Employee getManager() {
		return manager;
	}

	public void setManager(Employee manager) {
		this.manager = manager;
	}
	
	public void addEmployee(Employee employee) {
		if (!employees.contains(employee)) {
			// add employee to this department's list
			employees.add(employee);
			// remove employee from their old department
			if (employee.getDepartment() != null) {
				employee.getDepartment().getEmployees().remove(employee);
			}
			// Bidirectional, so add department to the employee
			employee.setDepartment(this);
		}
	}
	
	public void removeEmployee(Employee employee) {
		if (employees.contains(employee))  {
			// remove employee from this department's list
			employees.remove(employee);
			// Bidirectional, so null out the department in the employee
			employee.setDepartment(null);
		}
	}

}