package entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="JOBS")
public class Job {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String name;
	@Column(name="minimum_salary")
	private int minimumSalary;
	@Column(name="maximum_salary")
	private int maximumSalary;
	
	@OneToMany(mappedBy="job")
	private List<Employee> employees;
	
	public Job() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMinimumSalary() {
		return minimumSalary;
	}

	public void setMinimumSalary(int minimumSalary) {
		this.minimumSalary = minimumSalary;
	}

	public int getMaximumSalary() {
		return maximumSalary;
	}

	public void setMaximumSalary(int maximumSalary) {
		this.maximumSalary = maximumSalary;
	}

	public int getId() {
		return id;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	
	
}
