package entities;

public enum Gender {
	M,F;
}
