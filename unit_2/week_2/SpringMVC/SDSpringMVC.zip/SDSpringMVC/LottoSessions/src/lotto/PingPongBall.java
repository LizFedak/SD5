package lotto;

public class PingPongBall {
	private String value;
	
	public PingPongBall(String v) {
		value = v;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
