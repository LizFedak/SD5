package solutions;

public enum Suit {
    HEARTS, SPADES, CLUBS, DIAMONDS
}
