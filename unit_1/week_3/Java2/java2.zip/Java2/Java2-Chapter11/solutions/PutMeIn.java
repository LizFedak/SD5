package solutions;

import java.sql.*;

public class PutMeIn {
    private static String URL = "jdbc:mysql://localhost:3306/companydb";
    public static void main(String args[]) {
        String user = "student";
        String pword = "student";
        String sqltxt;
        sqltxt = "INSERT INTO employees (firstname, lastname, "
                + "department_id, job_id, hiredate, salary) "
                + " VALUES ('Rob', 'Roselius', "
                + "3, 13, curdate(), 45000 )";
        
        try (Connection conn = DriverManager.getConnection(URL,user,pword);
                Statement stmt = conn.createStatement();) {
            int uc = stmt.executeUpdate(sqltxt);
            System.out.println("\n" + uc + " row(s) updated.");
        }
        catch (SQLException sqle) {
            sqle.printStackTrace();
        }
    }
}
