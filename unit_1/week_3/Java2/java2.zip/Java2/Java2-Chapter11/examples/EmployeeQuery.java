package examples;

import java.sql.*;

public class EmployeeQuery {
    private static String URL = "jdbc:mysql://localhost:3306/companydb";
    public static void main(String args[]) {
        String user = "student";
        String pword = "student";
        String sqltxt = "SELECT id, firstname, lastname FROM employees";

        try (Connection conn = DriverManager.getConnection(URL, user, pword);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sqltxt);) {

            while (rs.next()) {
                System.out.println(rs.getString(1) + " "
                        + rs.getString(2) + " " + rs.getString(3));
            }
        }
        catch (SQLException e) {
            System.err.println(e);
        }
    }
}
