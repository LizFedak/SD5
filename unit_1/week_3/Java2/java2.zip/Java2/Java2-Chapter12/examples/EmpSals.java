package examples;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

public class EmpSals {

  public static void main(String args[]) {
    String url = "jdbc:mysql://localhost:3306/companydb";
    String user = "student";
    String pword = "student";
    String sqltxt;
    sqltxt = "SELECT firstname, lastname, salary, departments.name"
     + " FROM employees JOIN departments "
     + " ON employees.department_id = departments.id";

    try (Connection conn = DriverManager.getConnection(url,user,pword);
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sqltxt);) {

      String name;
      String dept;
      float salary;
      while (rs.next()) {
        name = rs.getString("firstname") + " "
            + rs.getString("lastname");
        dept = rs.getString("name");
        salary = rs.getFloat("salary");
        System.out.println(name + "\t" + dept + "\t" + salary);
      }
    }
    catch (SQLException sqle) {
      System.err.println("SQL Error:");
      System.err.println("   Code: " + sqle.getErrorCode());
      System.err.println(" Message: " + sqle.getMessage());
    }
  }
}
