package examples;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PrepParamExample {
  public PrepParamExample() {
    String url = "jdbc:mysql://localhost:3306/companydb";
    String user = "student";
    String pword = "student";
    String sql = "SELECT name FROM departments "
        + "WHERE id = ?";

    try (Connection conn = DriverManager.getConnection(url,user,pword);
        PreparedStatement pst = conn.prepareStatement(sql);) {

      System.out.println(getDeptName(pst, 9));
      System.out.println(getDeptName(pst, 3));
    }
    catch (SQLException e) {
      System.err.println(e);
    }
  }

  private String getDeptName(PreparedStatement pst, int deptid)
      throws SQLException {
    pst.setInt(1, deptid);
    ResultSet rs = pst.executeQuery();
    String dept = "";
    while (rs.next()) {
      dept += rs.getString(1) + "\n";
    }
    return dept;
  }

  public static void main(String args[]) {
    new PrepParamExample();
  }
}
