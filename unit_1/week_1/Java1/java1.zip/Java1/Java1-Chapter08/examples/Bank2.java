package examples;

public class Bank2 {

    public static void main(String[] args) {
        Customer2 cust = new Customer2();
        cust.firstName = "Jim";
        cust.lastName = "Stewart";

        cust.addAccount(250.0);
    }
}
