package solutions;

public class EmpTest3 {
    public static void main(String[] args) {
        Employee3 e = new Employee3();
        e.firstName = "Bob";
        e.lastName = "Dobbs";
        e.salary = 59900.00F;
        e.id = 42;

        e.showEmp();
    }
}
