package solutions;

public class MIUnicode {
    public static void main(String[] args) {
        char first = '\u0044';
        char middle = '\u0053';
        char last = '\u0048';

        System.out.println("Initials: " + first + middle + last);
    }
}
