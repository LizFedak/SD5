package solutions;

public class Dog1 {
    public static void main(String[] args) {
        String name;
        float weight;
        int tailLength;
        boolean friendly;
    }
}
