package examples;

public enum HW {
    APPLE, SAMSUNG, HTC, MOTOROLA, NOKIA, RIM,
}
