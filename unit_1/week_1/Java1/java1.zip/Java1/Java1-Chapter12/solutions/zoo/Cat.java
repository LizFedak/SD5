package solutions.zoo;

public class Cat {
    String voice;

    public Cat() {
        voice = "roar";
    }

    @Override
    public String toString() {
        return voice;
    }
}
