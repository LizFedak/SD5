package solutions;

public interface Drawable {
    public void draw();
}